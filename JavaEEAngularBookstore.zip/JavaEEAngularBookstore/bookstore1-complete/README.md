Backend (1)

Initial exercise to add and remove books from a Hashmap