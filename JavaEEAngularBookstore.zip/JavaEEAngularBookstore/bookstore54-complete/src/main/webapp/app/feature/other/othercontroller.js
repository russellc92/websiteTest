(function() {

    var OtherController =  function() {
        var vm = this;
    };

    angular.module('bookStore').controller('OtherController', [OtherController]);
}());