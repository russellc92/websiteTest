# JavaEEAngularBookstore

A simple series of coding exercises to accompany the JavaEE / Angular JS module.
