Backend (3)

Third exercise on pulling in external lib and converting book to json using GSON.

