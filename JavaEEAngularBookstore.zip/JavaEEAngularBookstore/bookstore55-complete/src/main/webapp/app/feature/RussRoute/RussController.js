(function() {

    var RussController =  function() {
        var vm = this;
    };

    angular.module('bookStore').controller('RussController', [RussController]);
}());