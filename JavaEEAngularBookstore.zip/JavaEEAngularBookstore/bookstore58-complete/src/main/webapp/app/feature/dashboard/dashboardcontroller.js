(function() {

    var DashBoardController =  function() {
        var vm = this;
    };

    angular.module('bookStore').controller('dashBoardController', [DashBoardController]);
}());