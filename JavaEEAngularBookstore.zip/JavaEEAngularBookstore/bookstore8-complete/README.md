Backend (8)

Adding a DB, EJB and alternative impl