insert into BookStore (id, author, title, genre, yearPublished) values (0, 'Stephen King', 'IT', 'Horror', '1988') 
