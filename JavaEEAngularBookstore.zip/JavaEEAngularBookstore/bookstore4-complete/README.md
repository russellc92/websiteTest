Backend (4)

Fourth exercise on using TDD.