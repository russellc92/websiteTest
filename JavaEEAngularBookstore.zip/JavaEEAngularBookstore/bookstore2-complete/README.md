Backend (2)

Second exercise on adding sonar properties and git ignore file