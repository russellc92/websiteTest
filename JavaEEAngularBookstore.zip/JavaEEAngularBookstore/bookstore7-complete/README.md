Backend (7)

Final week exercise brining all first week concepts together