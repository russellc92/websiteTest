Backend (5)

Fifth exercise adding more functionality.