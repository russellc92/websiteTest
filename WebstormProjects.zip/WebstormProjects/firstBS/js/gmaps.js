
var mapProp= {
    center:new google.maps.LatLng(51.508742,-0.120850),
    zoom:2,
};
var map= new google.maps.Map(document.getElementById("googleMap"),mapProp);
var myCenter = new google.maps.LatLng(51.508742,-0.120850);
var marker2;
var marker;
var marker3;
var marker4;
var marker5;
var marker6;

function myMap() {
        mapProp= {
            center:new google.maps.LatLng(51.508742,-0.120850),
            zoom:2,
        };
         map= new google.maps.Map(document.getElementById("googleMap"),mapProp);
         myCenter = new google.maps.LatLng(51.508742,-0.120850);





         marker = new google.maps.Marker({position:myCenter, animation:google.maps.Animation.BOUNCE});
        marker.setMap(map);

        google.maps.event.addListener(marker,'click',function() {
            map.setZoom(9);
            map.setCenter(marker.getPosition());
        });

        var infowindow = new google.maps.InfoWindow({
            content:"London cinema  !"
        });

        google.maps.event.addListener(marker, 'click', function() {
            infowindow.open(map,marker);
        });


        var random = new google.maps.LatLng( 53.278353, -2.362061 );
        marker2 = new google.maps.Marker({position:random, animation:google.maps.Animation.BOUNCE});
        marker2.setMap(map);

        google.maps.event.addListener(marker2,'click',function() {
            map.setZoom(9);
            map.setCenter(marker2.getPosition());
        });


        var infowindow2 = new google.maps.InfoWindow({
            content:"Manchesterish cinema   !"
        });

        google.maps.event.addListener(marker2, 'click', function() {
            infowindow2.open(map,marker2);
        });

        var random = new google.maps.LatLng( 51.781436, -1.263428 );
        marker3 = new google.maps.Marker({position:random, animation:google.maps.Animation.BOUNCE});
        marker3.setMap(map);

        google.maps.event.addListener(marker3,'click',function() {
            map.setZoom(9);
            map.setCenter(marker3.getPosition());
        });


        var infowindow3 = new google.maps.InfoWindow({
            content:"Oxford based cinema!"
        });

        google.maps.event.addListener(marker3, 'click', function() {
            infowindow3.open(map,marker3);
        });

        var random = new google.maps.LatLng( 52.187405, 0.142822 );
        marker4 = new google.maps.Marker({position:random, animation:google.maps.Animation.BOUNCE});
        marker4.setMap(map);

        google.maps.event.addListener(marker4,'click',function() {
            map.setZoom(9);
            map.setCenter(marker4.getPosition());
        });

        var infowindow4 = new google.maps.InfoWindow({
            content:"Cambridge Cinema!"
        });

        google.maps.event.addListener(marker4, 'click', function() {
            infowindow4.open(map,marker4);
        });

        var random = new google.maps.LatLng( (Math.random()*(85*2)-85), (Math.random()*(180*2)-180) );
        marker5 = new google.maps.Marker({position:random, animation:google.maps.Animation.BOUNCE});
        marker5.setMap(map);

        google.maps.event.addListener(marker5,'click',function() {
            map.setZoom(9);
            map.setCenter(marker5.getPosition());
        });


        var infowindow5 = new google.maps.InfoWindow({
            content:"turles!"
        });

        google.maps.event.addListener(marker5, 'click', function() {
            infowindow5.open(map,marker5);
        });

    }

    function mancPin() {
        /*var random = new google.maps.LatLng( (Math.random()*(85*2)-85), (Math.random()*(180*2)-180) );
        var marker6 = new google.maps.Marker({position:random, animation:google.maps.Animation.BOUNCE});
        marker6.setMap(map);

        google.maps.event.addListener(marker6,'click',function() {
            map.setZoom(9);
            map.setCenter(marker6.getPosition()); });*/

        // marker2
        map.setZoom(10);
        map.panTo(marker2.position);
    }

function londonPin() {
    map.setZoom(10);
    map.panTo(marker.position);
}
function oxPin() {
    map.setZoom(10);
    map.panTo(marker3.position);
}