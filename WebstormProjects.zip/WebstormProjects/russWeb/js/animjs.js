function changeImg(x) {

    x.style.opacity = "0.25";



}

function normalImg(x) {

    x.style.opacity = "1";


}